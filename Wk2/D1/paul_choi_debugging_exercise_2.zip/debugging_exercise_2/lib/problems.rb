# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.
require "byebug"
def largest_prime_factor(num)
    arr = []
    (2..num).each do |i|
    
        arr << i if prime?(i) && num % i == 0
    end
 arr.last
end

def prime?(num)
    (2...num).each do |i|
        if num % i == 0
            return false
        end
    end
    true
end

def unique_chars?(str)
    str.each_char.with_index do |char1, idx1|
        str.each_char.with_index do |char2, idx2|
            if idx2 > idx1 && char2 == char1
                return false
            end
        end
    end
    true
end
        
def dupe_indices(arr)
    ans = Hash.new { |k, v| k[v] = []} #how to set default value of a hash value as arr where values can be pushed into/
    arr.each_with_index do |ele, idx|
        ans[ele] << idx if arr.count(ele) >= 2
    end
    ans
end

def ana_array(arr1, arr2)
    if arr1.length != arr2.length
        return false
    elsif arr2.length <= arr1.length
        arr2.each { |ele|return false if !arr1.any?(ele) }
    elsif arr1.length > arr2.length
            arr1.each  {|ele| return false if !arr2.any?(ele)}     
    end
true
end